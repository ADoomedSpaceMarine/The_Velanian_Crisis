How to play this mod:

1) Have a copy of GZDoom, a copy of any copy of Doom, Doom 2, Plutonia, or TNT (Preferrably a legal one)
2) Place the build .pk3 in your GZDoom directory once you have extracted GZDoom to a folder of your choosing
3) Either run it the old fashion way by starting GZDoom in the run command 
   (Windows key + r) with the commandline parameters "-file "Name of build here".pk3"
   after the path to the program
   
   OR (The easy way)
   
   Find yourself a copy of a nifty launcher program called "ZDL" and look up how to use it. It's a lot quicker 
   passing multiple files through the command line parameters provided by the run command method.

4) Play the mod! 

I hope you find great enjoyment in the mod, as I have put a lot of time and effort into delivering the
coolest Doom experience I am capable of to you, the user.

Have a blessed day.

ADoomedSpaceMarine out.   